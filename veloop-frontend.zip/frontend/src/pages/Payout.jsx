import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getWallet, getPayoutMethods, getPayoutOptions, createWithdrawal, errMsg } from "../api";

const fmt = (n) => Number(n ?? 0).toLocaleString("en-IN");
const UPI_RE = /^[a-zA-Z0-9._-]{2,256}@[a-zA-Z]{2,64}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Client-side checks are for UX only. The backend validates everything again.
function validate(method, value) {
  if (method === "upi") return UPI_RE.test(value) ? "" : "Enter a valid UPI ID, e.g. name@okaxis.";
  return EMAIL_RE.test(value) ? "" : "Enter a valid email address for gift card delivery.";
}

export default function Payout() {
  const nav = useNavigate();
  const [ves, setVes] = useState(0);
  const [methods, setMethods] = useState([]);
  const [method, setMethod] = useState(null);
  const [options, setOptions] = useState([]);
  const [optionId, setOptionId] = useState(null);
  const [detail, setDetail] = useState("");
  const [fieldErr, setFieldErr] = useState("");
  const [loading, setLoading] = useState(true);
  const [optLoading, setOptLoading] = useState(false);
  const [error, setError] = useState("");
  const [confirming, setConfirming] = useState(false);
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(null);
  const idemKey = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const [w, m] = await Promise.all([getWallet(), getPayoutMethods()]);
        setVes(w.ves);
        setMethods(m);
        if (m[0]) pick(m[0].method);
      } catch (e) {
        setError(errMsg(e));
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line
  }, []);

  const pick = async (m) => {
    setMethod(m);
    setOptionId(null);
    setDetail("");
    setFieldErr("");
    setError("");
    setOptLoading(true);
    try {
      setOptions(await getPayoutOptions(m));
    } catch (e) {
      setOptions([]);
      setError(errMsg(e));
    } finally {
      setOptLoading(false);
    }
  };

  const selected = options.find((o) => o.optionId === optionId);

  const review = () => {
    const msg = validate(method, detail.trim());
    setFieldErr(msg);
    if (msg) return;
    idemKey.current = crypto.randomUUID(); // one key per confirmed attempt -> double-click safe
    setConfirming(true);
  };

  const confirm = async () => {
    if (busy) return;
    setBusy(true);
    setError("");
    try {
      const payoutDetails = method === "upi" ? { upiId: detail.trim() } : { email: detail.trim() };
      const res = await createWithdrawal({ method, optionId, payoutDetails }, idemKey.current);
      setDone(res.withdrawal || res);
      setConfirming(false);
      setVes((await getWallet()).ves); // refresh from backend
    } catch (e) {
      setError(errMsg(e));
      setConfirming(false);
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <p className="muted">Loading payout options…</p>;

  if (done)
    return (
      <div className="panel narrow center">
        <h1>Withdrawal submitted</h1>
        <p>Status: <span className="tag pending">{done.status || "PENDING"}</span></p>
        <p className="muted">Remaining balance: {fmt(ves)} VEs</p>
        <button className="btn" onClick={() => nav("/wallet")}>Back to wallet</button>
      </div>
    );

  return (
    <>
      <section className="hero slim">
        <div>
          <div className="muted">Available VEs</div>
          <div className="big sm">{fmt(ves)}</div>
        </div>
      </section>

      {error && <div className="alert err">{error}</div>}

      <section className="panel">
        <h2>Payout method</h2>
        <div className="tabs">
          {methods.map((m) => (
            <button key={m.method} className={`tab ${method === m.method ? "on" : ""}`} onClick={() => pick(m.method)}>
              {m.name}
            </button>
          ))}
        </div>

        <h2>Choose an amount</h2>
        {optLoading ? (
          <p className="muted">Loading…</p>
        ) : options.length === 0 ? (
          <p className="muted">No options are available for this method right now.</p>
        ) : (
          <div className="opts">
            {options.map((o) => {
              const enough = ves >= o.requiredAmount;
              const usable = o.active !== false && o.eligible !== false && enough;
              return (
                <button
                  key={o.optionId}
                  disabled={!usable}
                  className={`opt ${optionId === o.optionId ? "on" : ""}`}
                  onClick={() => setOptionId(o.optionId)}
                >
                  <strong>₹{fmt(o.payoutValue)}</strong>
                  <span>{fmt(o.requiredAmount)} VEs</span>
                  {!usable && <em>{enough ? "Unavailable" : "Not enough VEs"}</em>}
                </button>
              );
            })}
          </div>
        )}

        {selected && (
          <>
            <h2>{method === "upi" ? "Your UPI ID" : "Delivery email"}</h2>
            <input
              value={detail}
              onChange={(e) => setDetail(e.target.value)}
              placeholder={method === "upi" ? "name@okaxis" : "you@example.com"}
              autoComplete="off"
            />
            {fieldErr && <div className="field-err">{fieldErr}</div>}
            <button className="btn" style={{ marginTop: 16 }} onClick={review}>Review redemption</button>
          </>
        )}
      </section>

      {confirming && selected && (
        <div className="modal-bg" role="dialog" aria-modal="true">
          <div className="modal">
            <h2>Are you sure you want to redeem this reward?</h2>
            <p>Payout: <strong>₹{fmt(selected.payoutValue)}</strong></p>
            <p>Required: <strong>{fmt(selected.requiredAmount)} VEs</strong></p>
            <p className="muted">{detail}</p>
            <div className="row">
              <button className="btn ghost" onClick={() => setConfirming(false)} disabled={busy}>Cancel</button>
              <button className="btn" onClick={confirm} disabled={busy}>{busy ? "Submitting…" : "Confirm"}</button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
