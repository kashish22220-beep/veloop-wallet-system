import { useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { getWallet, getTransactions, errMsg } from "../api";

const CURRENCIES = [
  { key: "ves", label: "VEs", big: true },
  { key: "sves", label: "SVEs" },
  { key: "gems", label: "Gems" },
  { key: "tokens", label: "Tokens" },
  { key: "spins", label: "Spins" },
];
const fmt = (n) => Number(n ?? 0).toLocaleString("en-IN");

export default function Wallet() {
  const nav = useNavigate();
  const [wallet, setWallet] = useState(null);
  const [tx, setTx] = useState({ transactions: [], pagination: { page: 1, pages: 1 } });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [w, t] = await Promise.all([getWallet(), getTransactions(page, 10)]);
      setWallet(w);
      setTx(t);
    } catch (e) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  if (loading && !wallet) return <p className="muted">Loading wallet…</p>;
  if (error && !wallet)
    return (
      <div className="alert err">
        {error} <button className="link" onClick={load}>Retry</button>
      </div>
    );

  const { pages = 1 } = tx.pagination || {};

  return (
    <>
      <section className="hero">
        <div>
          <div className="muted">Available VEs</div>
          <div className="big">{fmt(wallet?.ves)}</div>
        </div>
        <button className="btn gold" onClick={() => nav("/payout")}>Withdraw / Redeem</button>
      </section>

      <section className="grid">
        {CURRENCIES.filter((c) => !c.big).map((c) => (
          <div className="panel stat" key={c.key}>
            <div className="muted">{c.label}</div>
            <div className="num">{fmt(wallet?.[c.key])}</div>
          </div>
        ))}
      </section>

      <section className="panel">
        <h2>Transaction history</h2>
        {error && <div className="alert err">{error}</div>}
        {tx.transactions.length === 0 ? (
          <p className="muted">No transactions yet. Earn VEs to see activity here.</p>
        ) : (
          <div className="scroll">
            <table>
              <thead>
                <tr><th>Date</th><th>Description</th><th>Status</th><th className="r">Amount</th></tr>
              </thead>
              <tbody>
                {tx.transactions.map((t) => {
                  const credit = t.type === "CREDIT";
                  return (
                    <tr key={t.transactionId || t._id}>
                      <td>{new Date(t.createdAt).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" })}</td>
                      <td>{t.description || t.source}</td>
                      <td><span className={`tag ${String(t.status).toLowerCase()}`}>{t.status}</span></td>
                      <td className={`r ${credit ? "pos" : "neg"}`}>
                        {credit ? "+" : "−"}{fmt(t.amount)} {String(t.currency).toUpperCase()}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
        <div className="pager">
          <button className="btn ghost" disabled={page <= 1} onClick={() => setPage(page - 1)}>Previous</button>
          <span className="muted">Page {page} of {pages}</span>
          <button className="btn ghost" disabled={page >= pages} onClick={() => setPage(page + 1)}>Next</button>
        </div>
      </section>
    </>
  );
}
