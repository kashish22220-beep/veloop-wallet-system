import { createContext, useContext, useState } from "react";
import { Navigate } from "react-router-dom";
import { getToken, setToken, login as apiLogin } from "./api";

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [authed, setAuthed] = useState(!!getToken());

  const login = async (email, password) => {
    const data = await apiLogin(email, password);
    setToken(data.token);
    setAuthed(true);
  };
  const logout = () => {
    setToken(null);
    setAuthed(false);
  };
  return <Ctx.Provider value={{ authed, login, logout }}>{children}</Ctx.Provider>;
}

export function Protected({ children }) {
  const { authed } = useAuth();
  return authed ? children : <Navigate to="/login" replace />;
}
