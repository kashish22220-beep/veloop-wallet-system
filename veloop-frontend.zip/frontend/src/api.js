import axios from "axios";

// Only the JWT lives in localStorage. Balances ALWAYS come from the backend.
const TOKEN_KEY = "veloop_token";
export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (t) => (t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY));

const api = axios.create({ baseURL: import.meta.env.VITE_API_URL || "http://localhost:5000/api" });

api.interceptors.request.use((cfg) => {
  const t = getToken();
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});

api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && !err.config.url.includes("/auth/")) {
      setToken(null);
      window.location.href = "/login";
    }
    return Promise.reject(err);
  }
);

export const errMsg = (e) => e.response?.data?.message || "Something went wrong. Please try again.";

export const login = (email, password) => api.post("/auth/login", { email, password }).then((r) => r.data);
export const getWallet = () => api.get("/wallet").then((r) => r.data.wallet);
export const getTransactions = (page = 1, limit = 10) =>
  api.get("/wallet/transactions", { params: { page, limit } }).then((r) => r.data);
export const getPayoutMethods = () => api.get("/payout/methods").then((r) => r.data.methods);
export const getPayoutOptions = (method) => api.get(`/payout/options/${method}`).then((r) => r.data.options);

// Frontend sends ONLY method + optionId + details. Never an amount.
export const createWithdrawal = (body, idempotencyKey) =>
  api.post("/withdrawals", body, { headers: { "Idempotency-Key": idempotencyKey } }).then((r) => r.data);
