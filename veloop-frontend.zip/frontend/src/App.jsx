import { Routes, Route, Navigate, NavLink, useLocation } from "react-router-dom";
import { useAuth, Protected } from "./AuthContext.jsx";
import Login from "./pages/Login.jsx";
import Home from "./pages/Home.jsx";
import Wallet from "./pages/Wallet.jsx";
import Payout from "./pages/Payout.jsx";

export default function App() {
  const { authed, logout } = useAuth();
  const onHome = useLocation().pathname === "/";
  return (
    <>
      {!onHome && <header className="bar">
        <span className="logo">VELoop<i>Rewards</i></span>
        {authed && (
          <nav>
            <NavLink to="/wallet">Wallet</NavLink>
            <NavLink to="/payout">Payout</NavLink>
            <button className="link" onClick={logout}>Log out</button>
          </nav>
        )}
      </header>}
      {onHome ? <Home /> : <main>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/wallet" element={<Protected><Wallet /></Protected>} />
          <Route path="/payout" element={<Protected><Payout /></Protected>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>}
    </>
  );
}
