const rateLimit = require('express-rate-limit');

const handler = (message) => (req, res) =>
  res.status(429).json({ success: false, message, code: 'RATE_LIMITED' });

// Login / register: per IP
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  handler: handler('Too many attempts. Please try again later.'),
});

// Wallet mutations and withdrawals: per authenticated user (use AFTER authenticate)
const mutationLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 20,
  standardHeaders: true,
  legacyHeaders: false,
  keyGenerator: (req) => String(req.user._id),
  handler: handler('Too many requests. Please slow down.'),
});

// General API limiter: per IP
const apiLimiter = rateLimit({
  windowMs: 60 * 1000,
  limit: 200,
  standardHeaders: true,
  legacyHeaders: false,
  handler: handler('Too many requests. Please slow down.'),
});

module.exports = { authLimiter, mutationLimiter, apiLimiter };
